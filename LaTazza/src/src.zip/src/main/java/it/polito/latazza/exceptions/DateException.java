package it.polito.latazza.exceptions;

public class DateException extends Exception {

	private static final long serialVersionUID = 1L;

}
