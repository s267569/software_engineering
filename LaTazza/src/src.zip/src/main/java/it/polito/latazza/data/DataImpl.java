package it.polito.latazza.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import it.polito.latazza.exceptions.BeverageException;
import it.polito.latazza.exceptions.DateException;
import it.polito.latazza.exceptions.EmployeeException;
import it.polito.latazza.exceptions.NotEnoughBalance;
import it.polito.latazza.exceptions.NotEnoughCapsules;

public class DataImpl implements DataInterface {
	private Map<Integer,CapsuleType> capsules = new HashMap<Integer,CapsuleType>();
	private Map<Integer,Collegue> collegues= new HashMap<Integer,Collegue>();
	private Integer cashAccount = 0;
	private String databaseName = "DataBase.csv";
	private String sourceDB = "SourceDB.csv";
	private boolean boot = true;
	
	public DataImpl() {
		// TODO Auto-generated constructor stub
		
		String line = "";
		String[] fields;
		
		//fill the data structures
		
		try(BufferedReader reader = new BufferedReader(new FileReader(new File(sourceDB)))){
			
			//iterate over the lines of the file
			while((line = reader.readLine()) != null) {
				
				fields = line.split(",");
				
				switch(fields[0]) {
							
				case "BEV":
					createBeverage(fields[2], Integer.valueOf(fields[3]), Integer.valueOf(fields[4]));
					break;
				case "UPBEV":
					updateBeverage(Integer.valueOf(fields[1]), fields[2], Integer.valueOf(fields[3]), Integer.valueOf(fields[4]));
					break;
				case "EMP":
					createEmployee(fields[6], fields[7]);
					break;
				case "UPEMP":
					updateEmployee(Integer.valueOf(fields[5]), fields[6], fields[7]);
					break;
				default:
					break;		
				}
			}
			
			reader.close();
			
		}catch(IOException ex) {
			System.err.println("IOException - " + ex.getMessage());
		}catch(EmployeeException em) {
			System.err.println("[boot]EmployeeException - " + em.getMessage());
		}catch(BeverageException be) {
			System.err.println("[boot]BeverageException - " + be.getMessage());
		}
		
		//redo the transactions
		
		try(BufferedReader reader = new BufferedReader(new FileReader(new File(databaseName)))){
			
			//iterate over the lines of the file
			while((line = reader.readLine()) != null) {
				
				fields = line.split(",");
				
				switch(fields[1]) {
							
				case "CASH":
					sellCapsules(Integer.valueOf(fields[7]), Integer.valueOf(fields[8]), Integer.valueOf(fields[4]), false);
					break;
				case "BALANCE":
					sellCapsules(Integer.valueOf(fields[7]), Integer.valueOf(fields[8]), Integer.valueOf(fields[4]), true);
					break;
				case "RECHARGE":
					rechargeAccount(Integer.valueOf((fields[7])), Integer.valueOf(fields[5]));
					break;
				case "VISITOR":
					sellCapsulesToVisitor(Integer.valueOf(fields[8]), Integer.valueOf(fields[4]));
					break;
				case "BUY":
					buyBoxes(Integer.valueOf(fields[8]), Integer.valueOf(fields[6]));
					break;
				default:
					break;		
				}
			}
			
			reader.close();
			
		}catch(IOException ex) {
			System.err.println("IOException - " + ex.getMessage());
		}catch(EmployeeException em) {
			System.err.println("[boot]EmployeeException - " + em.getMessage());
		}catch(BeverageException be) {
			System.err.println("[boot]BeverageException - " + be.getMessage());
		}catch(NotEnoughCapsules noc) {
			System.err.println("[boot]NotEnoughCapsules - " + noc.getMessage());
		}catch(NotEnoughBalance nob) {
			System.err.println("[boot]NotEnoughBalance - " + nob.getMessage());
		}
		
		//boot procedures terminated
		boot = false;
	}
	

	@Override
	public Integer sellCapsules(Integer employeeId, Integer beverageId, Integer numberOfCapsules, Boolean fromAccount)
			throws EmployeeException, BeverageException, NotEnoughCapsules {
		// TODO Auto-generated method stub
		
		//employee id not valid 
		if(!collegues.containsKey(employeeId))
			throw new EmployeeException();
		
		//capsule not valid
		if(!capsules.containsKey(beverageId))
			throw new BeverageException();
		
		//negative number of capsules
		if(numberOfCapsules==null||numberOfCapsules<0)
			throw new NotEnoughCapsules();
		
		//not enough capsules
		if(capsules.get(beverageId).getQuantityAvailable() + capsules.get(beverageId).getNewQuantityAvailable() - numberOfCapsules < 0)
			throw new NotEnoughCapsules();
		
		if(capsules.get(beverageId).getQuantityAvailable() < numberOfCapsules) {
			
			int missed = numberOfCapsules - capsules.get(beverageId).getQuantityAvailable();
			
			//decrease number of capsules available
			capsules.get(beverageId).decreaseQuantity(capsules.get(beverageId).getQuantityAvailable());
			
			//if payment with account, decrease balance of employee
			if(fromAccount) {
				collegues.get(employeeId).decreaseBalance((numberOfCapsules - missed)*capsules.get(beverageId).getPrice());
			}else {
			
				//increase cashAccount
				cashAccount+=(numberOfCapsules - missed)*capsules.get(beverageId).getPrice();
			}
			
			capsules.get(beverageId).setQuantityAvailable(capsules.get(beverageId).getNewQuantityAvailable());
			capsules.get(beverageId).setPrice(capsules.get(beverageId).getNewPrice());
			capsules.get(beverageId).setNewPrice(0);
			capsules.get(beverageId).setNewQuantityAvailable(0);
			
			//decrease number of capsules available
			capsules.get(beverageId).decreaseQuantity(missed);
			
			//if payment with account, decrease balance of employee
			if(fromAccount) {
				collegues.get(employeeId).decreaseBalance(missed*capsules.get(beverageId).getPrice());
			}else {
			
				//increase cashAccount
				cashAccount+=missed*capsules.get(beverageId).getPrice();
			}
			
		}else {
			//decrease number of capsules available
			capsules.get(beverageId).decreaseQuantity(numberOfCapsules);
			
			//if payment with account, decrease balance of employee
			if(fromAccount) {
				collegues.get(employeeId).decreaseBalance(numberOfCapsules*capsules.get(beverageId).getPrice());			
			}else {
			
				//increase cashAccount
				cashAccount+=numberOfCapsules*capsules.get(beverageId).getPrice();
			}
		}
		
		
		//writing on database
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(databaseName),true))){
				
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				String record = format.format(new Date()) + "," +		//[datetime]
								(fromAccount?"BALANCE":"CASH") + "," +		//BALANCE or CASH
								collegues.get(employeeId).getName() + " " + collegues.get(employeeId).getSurname() + "," +		//[employee] 
								capsules.get(beverageId).getName() + "," +		//[beverageName] 
								numberOfCapsules  + "," +		//[numberOfCapsules]
								"" + "," +		//[amount] empty
								"" + "," +		//[boxQuantity] empty
								employeeId + "," + //[employeeId]
								beverageId;		//[beverageId]
				writer.write(record);
				writer.newLine();
				
				writer.close();
				
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
			}
		}
		
		return collegues.get(employeeId).getBalance();
	}

	@Override
	public void sellCapsulesToVisitor(Integer beverageId, Integer numberOfCapsules)
			throws BeverageException, NotEnoughCapsules {
		// TODO Auto-generated method stub
		
		//capsule not valid
		if(!capsules.containsKey(beverageId))
			throw new BeverageException();
				
		if(numberOfCapsules==null || numberOfCapsules<0)
			throw new NotEnoughCapsules();
		//not enough capsules
		if(capsules.get(beverageId).getQuantityAvailable() + capsules.get(beverageId).getNewQuantityAvailable() - numberOfCapsules<0)
			throw new NotEnoughCapsules();
		if(capsules.get(beverageId).getQuantityAvailable() < numberOfCapsules) {
			
			int missed = numberOfCapsules - capsules.get(beverageId).getQuantityAvailable();
			
			//decrease quantity of capsules
			capsules.get(beverageId).decreaseQuantity(capsules.get(beverageId).getQuantityAvailable());
					
			//increase cashAccount
			cashAccount+=(numberOfCapsules - missed)*capsules.get(beverageId).getPrice();
			
			capsules.get(beverageId).setQuantityAvailable(capsules.get(beverageId).getNewQuantityAvailable());
			capsules.get(beverageId).setPrice(capsules.get(beverageId).getNewPrice());
			capsules.get(beverageId).setNewPrice(0);
			capsules.get(beverageId).setNewQuantityAvailable(0);
			
			//decrease quantity of capsules
			capsules.get(beverageId).decreaseQuantity(missed);
					
			//increase cashAccount
			cashAccount+=missed*capsules.get(beverageId).getPrice();
			
			
		}else {
			//decrease quantity of capsules
			capsules.get(beverageId).decreaseQuantity(numberOfCapsules);
					
			//increase cashAccount
			cashAccount+=numberOfCapsules*capsules.get(beverageId).getPrice();
		}
		//writing on database
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(databaseName),true))){
						
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						
				String record = format.format(new Date()) + "," +		//[datetime]
								"VISITOR" + "," +		//VISITOR
								"" + "," +		//[employee] empty 
								capsules.get(beverageId).getName() + "," +		//[beverageName] 
								numberOfCapsules  + "," +		//[numberOfCapsules]
								"" + "," +		//[amount] empty
								"" + "," +		//[boxQuantity] empty
								"" + "," + 		//[employeeId] empty
								beverageId;		//[beverageId]
				writer.write(record);
				writer.newLine();
				
				writer.close();
						
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
			}
		}
	}

	@Override
	public Integer rechargeAccount(Integer id, Integer amountInCents) throws EmployeeException {
		// TODO Auto-generated method stub
		
		//employee id not valid 
		if(!collegues.containsKey(id))
			throw new EmployeeException();
		
		if(amountInCents<0)
			throw new EmployeeException();
		
		//increase cashAccount
		cashAccount+=amountInCents;
		
		//writing on database
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(databaseName),true))){
						
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						
				String record = format.format(new Date()) + "," +		//[datetime]
								"RECHARGE" + "," +		//RECHARGE
								collegues.get(id).getName() + " " + collegues.get(id).getSurname() + "," +		//[employee] 
								"" + "," +		//[beverageName] empty 
								""  + "," +		//[numberOfCapsules] empty
								amountInCents + "," +		//[amount]
								"" + "," +		//[boxQuantity] empty
								id + "," + 		//[employeeId]
								"";		//[beverageId] empty
								
				writer.write(record);
				writer.newLine();
				
				writer.close();
						
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
			}
		}
		
		return collegues.get(id).increaseBalance(amountInCents);
	}

	@Override
	public void buyBoxes(Integer beverageId, Integer boxQuantity) throws BeverageException, NotEnoughBalance {
		// TODO Auto-generated method stub
		
		//capsule not valid
		if(!capsules.containsKey(beverageId))
			throw new BeverageException();
		
		if(boxQuantity<0)
			throw new BeverageException();
		
		//not enough balance
		if(cashAccount-boxQuantity*capsules.get(beverageId).getBoxPrice()<0)
			throw new NotEnoughBalance();
		
		cashAccount-=boxQuantity*capsules.get(beverageId).getBoxPrice();
		
		capsules.get(beverageId).increaseCapsules(boxQuantity*capsules.get(beverageId).getCapsulesPerBox());
		
		//writing on database
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(databaseName),true))){
								
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								
				String record = format.format(new Date()) + "," +		//[datetime]
								"BUY" + "," +		//BUY
								"" + "," +		//[employee] empty 
								capsules.get(beverageId).getName() + "," +		//[beverageName] 
								""  + "," +		//[numberOfCapsules] empty
								"" + "," +		//[amount] empty
								boxQuantity + "," +		//[boxQuantity]
								"" + "," + 		//[employeeId] empty
								beverageId;		//[beverageId]
				writer.write(record);
				writer.newLine();
				
				writer.close();
								
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
			}
		}
	}

	@Override
	public List<String> getEmployeeReport(Integer employeeId, Date startDate, Date endDate)
			throws EmployeeException, DateException {
		// TODO Auto-generated method stub
		
		//colleague not valid
		if(!collegues.containsKey(employeeId))
			throw new EmployeeException();
		
		if(startDate==null || endDate==null)
			throw new DateException();
		if(startDate.compareTo(endDate) > 0)
			throw new DateException();
		
		List<String> report = new ArrayList<String>();
		
		try(BufferedReader reader = new BufferedReader(new FileReader(new File(databaseName)))){
			
			DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			String line = "";
			
			//iterate over the lines of the file
			while((line = reader.readLine()) != null) {
				
				String[] fields = line.split(",");
				
				try{
					
					Date timestamp = dateformat.parse(fields[0]);
					
					if(startDate.compareTo(timestamp) < 0 && endDate.compareTo(timestamp) > 0) {
						//correct time interval
						
						if(!fields[7].isEmpty() && Integer.valueOf(fields[7]) == employeeId) {
						
							switch(fields[1]) {
								
							case "CASH":
								// [datetime] CASH [employee] [beverageName] [numberOfCapsules]
								report.add(fields[0] + " " + fields[1] + " " + fields[2] + " " + fields[3] + " " + fields[4]);
								break;
							case "BALANCE":
								// [datetime] CASH [employee] [beverageName] [numberOfCapsules]
								report.add(fields[0] + " " + fields[1] + " " + fields[2] + " " + fields[3] + " " + fields[4]);
								break;
							case "RECHARGE":
								//[datetime] RECHARGE [employee] [amount]
								report.add(fields[0] + " " + fields[1] + " " + fields[2] + " " + String.format("%.2f \u20ac", (Float.valueOf(fields[5])/100)).replaceAll("(\\d+)\\,(\\d+)", "$1.$2"));
								break;
							default:
								break;		
							}
						}
					}
					
					if(endDate.compareTo(timestamp) < 0) {
						//no need to go further
						break;
					}
				
				}catch(ParseException pex) {
					System.err.println("ParseException - " + pex.getMessage());
				}
				
			}
			
			reader.close();
			
		}catch(IOException ex) {
			System.err.println("IOException - " + ex.getMessage());
		}
		
		return report;
	}

	@Override
	public List<String> getReport(Date startDate, Date endDate) throws DateException {
		// TODO Auto-generated method stub
		
		if(startDate==null || endDate==null)
			throw new DateException();
		if(startDate.compareTo(endDate) > 0)
			throw new DateException();
				
		List<String> report = new ArrayList<String>();
				
		try(BufferedReader reader = new BufferedReader(new FileReader(new File(databaseName)))){
					
			DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					
			String line = "";
					
			//iterate over the lines of the file
			while((line = reader.readLine()) != null) {
						
				String[] fields = line.split(",");
						
				try{
							
					Date timestamp = dateformat.parse(fields[0]);
							
					if(startDate.compareTo(timestamp) < 0 && endDate.compareTo(timestamp) > 0) {
						//correct time interval
								
						switch(fields[1]) {
									
						case "CASH":
							// [datetime] CASH [employee] [beverageName] [numberOfCapsules]
							report.add(fields[0] + " " + fields[1] + " " + fields[2] + " " + fields[3] + " " + fields[4]);
							break;
						case "BALANCE":
							// [datetime] CASH [employee] [beverageName] [numberOfCapsules]
							report.add(fields[0] + " " + fields[1] + " " + fields[2] + " " + fields[3] + " " + fields[4]);
							break;
						case "RECHARGE":
							//[datetime] RECHARGE [employee] [amount]
							report.add(fields[0] + " " + fields[1] + " " + fields[2] + " " + String.format("%.2f \u20ac", (Float.valueOf(fields[5])/100)).replaceAll("(\\d+)\\,(\\d+)", "$1.$2"));
							break;
						case "VISITOR":
							//[datetime] VISITOR [beverageName] [numberOfCapsules]
							report.add(fields[0] + " " + fields[1] + " " + fields[3] + " " + fields[4]);
							break;
						case "BUY":
							//[datetime] BUY [beverageName] [boxQuantity]
							report.add(fields[0] + " " + fields[1] + " " + fields[3] + " " + fields[6]);
							break;
						default:
							break;		
						}
					}
							
					if(endDate.compareTo(timestamp) < 0) {
						//no need to go further
						break;
					}
						
				}catch(ParseException pex) {
					System.err.println("ParseException - " + pex.getMessage());
				}
						
			}
					
			reader.close();
					
		}catch(IOException ex) {
			System.err.println("IOException - " + ex.getMessage());
		}
		
		return report;
	}

	@Override
	public Integer createBeverage(String name, Integer capsulesPerBox, Integer boxPrice) throws BeverageException {
		// TODO Auto-generated method stub
		
		if(name == null || capsulesPerBox == null || boxPrice == null)
			throw new BeverageException();
		
		if(name=="")
			throw new BeverageException();
		
		if(capsulesPerBox<=0||boxPrice<=0)
			throw new BeverageException();
		
		Integer new_id=capsules.keySet().stream().max(Integer::compareTo).orElse(0) + 1;
		CapsuleType cap= new CapsuleType();
		cap.setId(new_id);
		cap.setName(name);
		cap.setPrice(boxPrice/capsulesPerBox);
		cap.setCapsulesPerBox(capsulesPerBox);
		cap.setBoxPrice(boxPrice);
		
				
		capsules.put(new_id, cap);
		
		//writing sourceDB
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(sourceDB),true))){
						
						
				String record = "BEV" + "," +		//BEV
								"" + "," +		//[beverageId] empty
								name + "," +		//[beverageName]
								capsulesPerBox + "," +		//[capsulesPerBox]
								boxPrice + "," +		//[boxPrice]
								"" + "," +		//[employeeId] empty
								"" + "," + 		//[employeeName] empty
								"" + "," +		//[employeeSurname] empty
								"" + "," +		//[cashAmount] empty
								"" + "," +		//[quantityCapsules]
								"";				//[quantityBalance] empty
						
				writer.write(record);
				writer.newLine();
				
				writer.close();
						
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
				throw new BeverageException();
			}
		}
		
		return new_id;
	}

	@Override
	public void updateBeverage(Integer id, String name, Integer capsulesPerBox, Integer boxPrice)
			throws BeverageException {
		// TODO Auto-generated method stub
		
		if(id == null || name == null || capsulesPerBox == null || boxPrice == null || name=="")
			throw new BeverageException();
		
		//capsule not valid
		if(!capsules.containsKey(id))
			throw new BeverageException();
		
		if(capsulesPerBox<=0||boxPrice<=0)
			throw new BeverageException();
		
		capsules.get(id).setName(name);
		capsules.get(id).setCapsulesPerBox(capsulesPerBox);
		capsules.get(id).setBoxPrice(boxPrice);
		capsules.get(id).setNewPrice(boxPrice/capsulesPerBox);//have to update also one capsule price (even if not specified in DataInterface.java)
		
		
		//writing sourceDB
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(sourceDB),true))){
								
								
				String record = "UPBEV" + "," +		//BEVUP
								id + "," +		//[beverageId]
								name + "," +		//[beverageName]
								capsulesPerBox + "," +		//[capsulesPerBox]
								boxPrice + "," +		//[boxPrice]
								"" + "," +		//[employeeId] empty
								"" + "," + 		//[employeeName] empty
								"" + "," +		//[employeeSurname] empty
								"" + "," +		//[cashAmount] empty
								"" + "," +		//[quantityCapsules]
								"";				//[quantityBalance] empty
								
				writer.write(record);
				writer.newLine();
				
				writer.close();
								
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
				throw new BeverageException();
			}
		}
	}

	@Override
	public String getBeverageName(Integer id) throws BeverageException {
		// TODO Auto-generated method stub
		
		//capsule not valid
		if(!capsules.containsKey(id))
			throw new BeverageException();
		
		return capsules.get(id).getName();
	}

	@Override
	public Integer getBeverageCapsulesPerBox(Integer id) throws BeverageException {
		// TODO Auto-generated method stub
		
		//capsule not valid
		if(!capsules.containsKey(id))
			throw new BeverageException();
				
		return capsules.get(id).getCapsulesPerBox();
	}

	@Override
	public Integer getBeverageBoxPrice(Integer id) throws BeverageException {
		// TODO Auto-generated method stub
		
		//capsule not valid
		if(!capsules.containsKey(id))
			throw new BeverageException();
				
		return capsules.get(id).getBoxPrice();
	}

	@Override
	public List<Integer> getBeveragesId() {
		// TODO Auto-generated method stub
		return new ArrayList<Integer>(capsules.keySet());
	}

	@Override
	public Map<Integer, String> getBeverages() {
		// TODO Auto-generated method stub
		Map<Integer,String> map = new HashMap<Integer,String>();
		
		for(Map.Entry<Integer, CapsuleType> el : capsules.entrySet())
			map.put(el.getKey(), el.getValue().getName());
		
		return map;
			
	}

	@Override
	public Integer getBeverageCapsules(Integer id) throws BeverageException {
		// TODO Auto-generated method stub
		
		//capsule not valid
		if(!capsules.containsKey(id))
			throw new BeverageException();
		
		return capsules.get(id).getQuantityAvailable() + capsules.get(id).getNewQuantityAvailable();
	}

	@Override
	public Integer createEmployee(String name, String surname) throws EmployeeException {
		// TODO Auto-generated method stub
		
		if(name == null || surname == null || name=="" || surname=="")
			throw new EmployeeException();
		
		Integer new_id = collegues.keySet().stream().max(Integer::compareTo).orElse(0) + 1;
		
		Collegue col= new Collegue();
		col.setId(new_id);
		col.setName(name);
		col.setSurname(surname);
		
		//add new beverage to the map
		if(collegues.containsValue(col))
			throw new EmployeeException();
		
		collegues.put(new_id, col);
		
		
		//writing sourceDB
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(sourceDB),true))){
										
										
				String record = "EMP" + "," +		//EMP
								"" + "," +		//[beverageId] empty
								"" + "," +		//[beverageName] empty
								"" + "," +		//[capsulesPerBox] empty
								"" + "," +		//[boxPrice] empty
								"" + "," +		//[employeeId] empty
								name + "," + 		//[employeeName]
								surname + "," +		//[employeeSurname]
								"" + "," +		//[cashAmount] empty
								"" + "," +		//[quantityCapsules]
								"";				//[quantityBalance] empty
										
				writer.write(record);
				writer.newLine();
				
				writer.close();
										
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
				throw new EmployeeException();
			}
		}
				
		return new_id;
	}

	@Override
	public void updateEmployee(Integer id, String name, String surname) throws EmployeeException {
		// TODO Auto-generated method stub
		
		if(name == null || surname == null || name=="" || surname=="")
			throw new EmployeeException();
		
		//employee id not valid 
		if(!collegues.containsKey(id))
			throw new EmployeeException();
		
		collegues.get(id).setName(name);
		collegues.get(id).setSurname(surname);
		
		//writing sourceDB
		if(!boot) {
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(sourceDB),true))){
												
												
				String record = "UPEMP" + "," +		//EMP
								"" + "," +		//[beverageId] empty
								"" + "," +		//[beverageName] empty
								"" + "," +		//[capsulesPerBox] empty
								"" + "," +		//[boxPrice] empty
								id + "," +		//[employeeId] empty
								name + "," + 		//[employeeName]
								surname + "," +		//[employeeSurname]
								"" + "," +		//[cashAmount] empty
								"" + "," +		//[quantityCapsules]
								"";				//[quantityBalance] empty
												
				writer.write(record);
				writer.newLine();
				
				writer.close();
												
			}catch(IOException ex) {
				System.err.println("IOException - " + ex.getMessage());
				throw new EmployeeException();
			}
		}
	}

	@Override
	public String getEmployeeName(Integer id) throws EmployeeException {
		// TODO Auto-generated method stub
		
		//employee id not valid 
		if(!collegues.containsKey(id))
			throw new EmployeeException();

		return collegues.get(id).getName();
	}

	@Override
	public String getEmployeeSurname(Integer id) throws EmployeeException {
		// TODO Auto-generated method stub
		
		//employee id not valid 
		if(!collegues.containsKey(id))
			throw new EmployeeException();

		return collegues.get(id).getSurname();

	}

	@Override
	public Integer getEmployeeBalance(Integer id) throws EmployeeException {
		// TODO Auto-generated method stub

		//employee id not valid 
		if(!collegues.containsKey(id))
			throw new EmployeeException();
		
		return collegues.get(id).getBalance();
	}

	@Override
	public List<Integer> getEmployeesId() {
		// TODO Auto-generated method stub
		return new ArrayList<Integer>(collegues.keySet());
	}

	@Override
	public Map<Integer, String> getEmployees() {
		// TODO Auto-generated method stub
		Map<Integer,String> map = new HashMap<Integer,String>();
		
		for(Map.Entry<Integer, Collegue> el : collegues.entrySet())
			map.put(el.getKey(), el.getValue().getName() + " " + el.getValue().getSurname());
		
		return map;

	}

	@Override
	public Integer getBalance() {
		// TODO Auto-generated method stub
		return cashAccount;
	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub
		cashAccount=0;
		capsules = new	HashMap<Integer,CapsuleType>();
		collegues = new HashMap<Integer,Collegue>();
		File source = new File(sourceDB);
		source.delete();
		File database = new File(databaseName);
		database.delete();
		
	}

}