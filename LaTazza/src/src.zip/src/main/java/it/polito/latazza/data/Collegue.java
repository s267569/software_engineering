package it.polito.latazza.data;

public class Collegue {
private	String name;
private String surname;
private Integer id;
private Integer balance = 0;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getSurname() {
	return surname;
}

public void setSurname(String surname) {
	this.surname = surname;
}

public Integer getId() {
	return id;
}

public void setId(Integer id){
	this.id=id;
}

public Integer getBalance() {
	return balance;
}

public Integer decreaseBalance(Integer value){
	balance=balance-value;
	return balance;
}

public Integer increaseBalance(Integer value){
	balance=balance+value;
	return balance;
}

}

