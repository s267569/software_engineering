package it.polito.latazza.data;

public class CapsuleType {
	private Integer id;
	private String name;
	private Integer price;
	private Integer newPrice = 0;
	private Integer capsulesPerBox;
	private Integer quantityAvailable = 0;
	private Integer newQuantityAvailable = 0;
	private Integer boxPrice;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id){
		this.id=id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getCapsulesPerBox() {
		return capsulesPerBox;
	}

	public void setCapsulesPerBox(Integer capsulesPerBox) {
		this.capsulesPerBox = capsulesPerBox;
	}

	public Integer getQuantityAvailable() {
		return quantityAvailable;
	}

	public Integer getBoxPrice() {
		return boxPrice;
	}

	public void setBoxPrice(Integer boxPrice) {
		this.boxPrice = boxPrice;
	}
	
	public Integer decreaseQuantity(Integer qta){
		quantityAvailable-=qta;
		return quantityAvailable;
	}
	
	public Integer increaseCapsules(Integer qta){
		if(newPrice == 0) {
			quantityAvailable+=qta;
		}else {
			newQuantityAvailable+=qta;
		}
		return quantityAvailable + newQuantityAvailable;
	}

	public Integer getNewPrice() {
		return newPrice;
	}

	public void setNewPrice(Integer newPrice) {
		this.newPrice = newPrice;
	}

	public Integer getNewQuantityAvailable() {
		return newQuantityAvailable;
	}

	public void setNewQuantityAvailable(Integer newQuantityAvailable) {
		this.newQuantityAvailable = newQuantityAvailable;
	}

	public void setQuantityAvailable(Integer quantityAvailable) {
		this.quantityAvailable = quantityAvailable;
	}

}
