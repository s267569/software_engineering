package it.polito.latazza.data;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assumptions.assumingThat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import it.polito.latazza.exceptions.BeverageException;
import it.polito.latazza.exceptions.DateException;
import it.polito.latazza.exceptions.EmployeeException;
import it.polito.latazza.exceptions.NotEnoughBalance;
import it.polito.latazza.exceptions.NotEnoughCapsules;

public class TestDataImpl {
    
   
	@Test
	public void testSellWithAccount() {
		DataImpl i = new DataImpl();
		
		try {
			int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,100);
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,1);
			int balance = i.getBalance();
			int availability = i.getBeverageCapsules(1);
			int accountBalance = i.getEmployeeBalance(1);
			i.sellCapsules(1,1,10,true);
			assertTrue(i.getBalance() == balance);
			assertTrue(i.getEmployeeBalance(1) == accountBalance - 20);
			assertTrue(i.getBeverageCapsules(1) ==availability - 10);
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellWithAccountFalse() {
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,100);
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,1); // availability = 100
			int balance = i.getBalance();
			int availability = i.getBeverageCapsules(idc);
			int accountBalance = i.getEmployeeBalance(id);
			i.sellCapsules(id,idc,10,false);
			assertTrue(i.getBalance() == balance + 20);
			assertTrue(i.getEmployeeBalance(id) == accountBalance);
			assertTrue(i.getBeverageCapsules(idc) ==availability - 10);
			
		} catch (EmployeeException e) {
			
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellWithAccountNotCapsules() {
		DataImpl i = new DataImpl();
		
		try {
			
			//balance = 1000
			// capsule = 0
			int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,2);
			i.rechargeAccount(id,50); 
			i.sellCapsules(id,idc,10,true);
			fail();
			
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}  catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellWithAccountFalseNotCapsules() {
		DataImpl i = new DataImpl();
		
		try {
			
			//balance = 1000
			// capsule = 0
			int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,100);
			i.rechargeAccount(id,50); 
			i.sellCapsules(id,idc,10,false);
			fail();
			
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}  catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellWithAccountNotEmployee() {
		DataImpl i = new DataImpl();
		
		try {
			
			//balance = 1000
			// capsule = 0
			//int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,100);
			//i.rechargeAccount(id,50); 
			i.sellCapsules(1000,idc,10,true);
			fail();
			
			
		} catch (EmployeeException e) {
			assertTrue(true);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellWithAccountNotBeverage() {
		DataImpl i = new DataImpl();
		
		try {
			
			//balance = 1000
			// capsule = 0
			int  id = i.createEmployee("Davide","Miro");
			//int idc = i.createBeverage("caffe",50,1);
			//i.rechargeAccount(id,50);
			//i.buyBoxes(idc,2); // availability = 100;
			i.sellCapsules(id,1000,10,true);
			fail();
			
			
		} catch (EmployeeException e) {
			
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}  catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellWithAccountNegativeCapsules() {
		DataImpl i = new DataImpl();
		
		try {
			
			//balance = 1000
			// capsule = 0
			int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,100);
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2); // availability = 100;
			i.sellCapsules(id,idc,-10,true);
			fail();
			
			
		} catch (EmployeeException e) {
			
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}  catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	/*
	@Test
	public void testSellWithAccountNotBalance() {
		
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			int  id = i.createEmployee("Davide","Miro");
			int id1 = i.createEmployee("Domenico","Cefalo");
			int idc = i.createBeverage("caffe",50,100);
			//i.rechargeAccount(id,100);
			i.rechargeAccount(id1,1000);
			i.buyBoxes(idc,2); // availability = 100
			i.sellCapsules(id,idc,10,true);
			fail();
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (NotEnoughCapsules e) {
			fail();
			
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	*/
	
	@Test
	public void testSellVisitor() {
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			int  id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffe",50,100);
			i.rechargeAccount(id, 1000);
			i.buyBoxes(idc,2); // availability = 100
			int balance = i.getBalance();
			int availability = i.getBeverageCapsules(idc);
			i.sellCapsulesToVisitor(idc,10);
			assertTrue(i.getBalance() == balance + 20);
			assertTrue(i.getBeverageCapsules(idc) ==availability - 10);
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellVisitorNotCapsuleAvailable() {
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			int idc = i.createBeverage("caffe",50,100);
			//i.buyBoxes(idc,2); // availability = 100
			//int balance = i.getBalance();
			//int availability = i.getBeverageCapsules(idc);
			i.sellCapsulesToVisitor(idc,1000);
			fail();
			
		}  catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (BeverageException e) {
			fail();
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			i.reset();
		}
	}

	
	
	@Test
	public void testSellVisitorNotBeverage() {
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			//int idc = i.createBeverage("caffe",50,100);
			i.sellCapsulesToVisitor(1000,10);
			fail();
			
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			//e.printStackTrace();
		} catch (BeverageException e) {
			assertTrue(true);
			//assertTrue(true);
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testSellVisitorNegativeBeverage() {
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			int idc = i.createBeverage("caffe",50,100);
			int id = i.createEmployee("Mario","Rossi");
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,6);
			i.sellCapsulesToVisitor(1000,-10);
			fail();
			
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
			//e.printStackTrace();
		} catch (BeverageException e) {
			assertTrue(true);
			//assertTrue(true);
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testRechargeAccount() {
		DataImpl i = new DataImpl();
		try {
			
			int id = i.createEmployee("Davide","Miro");
			int accountBalance = i.getBalance();
			i.rechargeAccount(id,50);
			assertTrue(i.getBalance() == accountBalance + 50);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testRechargeAccountNotEmployee() {
		DataImpl i = new DataImpl();
		try {
			i.rechargeAccount(1000,50);
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			assertTrue(true);
		}finally {
			i.reset();
		}
	}
	
	
	
	
	@Test
	public void testBuyBoxes() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",50,100);
			int capsules = i.getBeverageCapsules(id);
			int idempl = i.createEmployee("Marco", "Marchesi");
			i.rechargeAccount(idempl, 100);
			int balance = i.getBalance();
			i.buyBoxes(id,1);
			assertTrue(i.getBeverageCapsules(id) == capsules + 50);
			assertTrue(i.getBalance() == balance - 100);	
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}catch(EmployeeException e) {
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testBuyBoxesNotBeverage() {
		
		DataImpl i = new DataImpl();
		try {
			//int id= i.createBeverage("caffe",50,2);
		//	int balance = i.getBalance();
			i.buyBoxes(1000,6);
			fail();
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	@Test
	public void testBuyBoxesNotBalance() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",50,100);
			int balance = i.getBalance();
			i.buyBoxes(id,20);
			fail();
		
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			assertTrue(true);
		}finally {
			i.reset();
		}
	}
	@Test
	public void testBuyBoxesNegativeBoxes() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",50,100);
			int idr =i.createEmployee("Mario","Rossi");
			i.rechargeAccount(idr,1000);
			i.buyBoxes(id,-20);
			fail();
		
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	@Test
	public void testCreateBeverage() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",50,100);
			String name =i.getBeverageName(id);
			int capsXbox = i.getBeverageCapsulesPerBox(id);
			int boxPrice = i.getBeverageBoxPrice(id);
			assertTrue(name.equals("caffe"));
			assertTrue(capsXbox == 50);
			assertTrue(boxPrice == 100);
			
		
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
		
	}
	
	@Test
	public void testCreateBeverageNegativeBox() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",-50,100);
			fail();
			
		
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			assertTrue(true);
		}finally {
			i.reset();
		}
	}
	@Test
	public void testCreateBeverageNegativePrice() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",50,-100);
			fail();
			
		
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			assertTrue(true);
		}finally {
			i.reset();
		}
	}
	/*
	@Test
	public void testCreateBeverageSameName() {
		
		DataImpl i = new DataImpl();
		try {
			i.createBeverage("caffe",50,100);
			i.createBeverage("caffe",50,100); 
			fail();
			
		
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			assertTrue(true);
		} finally {
			i.reset();
		}
	}
	*/
	
	
	
	@Test
	public void testUpdateBeverage() {
		
		DataImpl i = new DataImpl();
		try {
			int id= i.createBeverage("caffe",50,100);
			i.updateBeverage(id, "the",30,60);
			
			String name = i.getBeverageName(id);
			int caps = i.getBeverageCapsulesPerBox(id);
			int boxPrice =i.getBeverageBoxPrice(id);
			int price = boxPrice/caps;
			assertTrue(name.equals("the"));
			assertTrue(boxPrice == 60);
			assertTrue(caps == 30);
			assertTrue(price == 2);
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	
	
	@Test
	public void testUpdateBeverageWrongId() {
		
		DataImpl i = new DataImpl();
		try {
			
			
			i.updateBeverage(1000,"caffè",50,100);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	
	@Test
	public void testUpdateBeverageNegativeCapsules() {
		
		DataImpl i = new DataImpl();
		try {
			
			int id1 =i.createBeverage("caffè",50,100);
			i.updateBeverage(id1, "caffè",-30,60);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testUpdateBeverageNegativeBox() {
		
		DataImpl i = new DataImpl();
		try {
			
			int id1 =i.createBeverage("caffè",50,100);
			i.updateBeverage(id1, "caffè",30,-60);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			
			e.printStackTrace();
		} finally {
			i.reset();
		}
	}
	
	
	@Test
	public void testGetBeverageNameInvalidId() {
		
		DataImpl i = new DataImpl();
		try {
			i.getBeverageName(1000);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			
			e.printStackTrace();
		} finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetBeverageCapsulesXBox() {
		
		DataImpl i = new DataImpl();
		try {
			i.getBeverageCapsulesPerBox(1000);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			
			e.printStackTrace();
		} finally {
			i.reset();
		}
	}
	@Test
	public void testGetBeverageBoxPrice() {
		
		DataImpl i = new DataImpl();
		try {
			i.getBeverageBoxPrice(1000);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
			
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetBeveragesId(){
		
		DataImpl i = new DataImpl();
		int id = 0;
		int id1 = 0;
		try {
			id = i.createBeverage("caffè",50,100);
			id1 = i.createBeverage("the",30,30);
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
		List<Integer> l = i.getBeveragesId();
		List<Integer> l1 = new ArrayList();
		l1.add(id);
		l1.add(id1);
		if(l.equals(l1))
			assertTrue(true);
		
		i.reset();
	}
	
	@Test
	public void testGetBeverages() {
		DataImpl i = new DataImpl();
		int id = 0;
		int id1 = 0;
		Map<Integer,String> m =null;
		try {
			id = i.createBeverage("caffè",50,100);
			id1 = i.createBeverage("the",30,30);
			m = i.getBeverages();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
		Map<Integer,String> m1 = new HashMap();
		
		m1.put(id,"caffè");
		m1.put(id1,"the");
		
		if(m.equals(m1)) {
			assertTrue(true);
			return;
		}
		fail();
	}
	@Test
	public void testGetBeverageCapsulesNotExist() {
		DataImpl i = new DataImpl();
		int id = 0;
		
		try {
			id = i.createBeverage("caffè",50,100);
			i.getBeverageCapsules(id+1);
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}finally {
			i.reset();
		}
	}
	/*
	@Test
	public void testCreateEmployeeSameName(){
		DataImpl i =new DataImpl();
		try {
			i.createEmployee("Davide","Miro");
			i.createEmployee("Davide","Moro");
		
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
		}finally {
			i.reset();
		}
		
		
		
	}
	*/
	/*
	@Test
	public void testCreateEmployeeSameSurname(){
		DataImpl i =new DataImpl();
		try {
			i.createEmployee("Davide","Miro");
			i.createEmployee("Davide","Moro");
		
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
		}finally {
			i.reset();
		}
		
		
	}
	*/
	/*
	@Test
	public void testCreateEmployeeSame() {
		DataImpl i =new DataImpl();
		try {
			i.createEmployee("Davide","Miro");
			i.createEmployee("Davide","Miro");
			fail();
		
		} catch (EmployeeException e) {
			assertTrue(true);
			// TODO Auto-generated catch block
		}finally {
			i.reset();
		}
	}
	*/
	@Test 
	public void testUpdateEmployee() {
		DataImpl i =new DataImpl();
		try {
			int id = i.createEmployee("Davide","Miro");
			i.updateEmployee(id,"Domenico","Cefalo");
			assertTrue(i.getEmployeeName(id)=="Domenico");
			assertTrue(i.getEmployeeSurname(id)=="Cefalo");
			
		
		} catch (EmployeeException e) {
			fail();
			// TODO Auto-generated catch block
		}finally {
			i.reset();
		}
		
	}
	@Test 
	public void testUpdateEmployeeNotExist() {
		DataImpl i =new DataImpl();
		try {
			int id = i.createEmployee("Davide","Miro");
			i.updateEmployee(id+1,"Domenico","Cefalo");
		    fail();
			
		
		} catch (EmployeeException e) {
			assertTrue(true);
			// TODO Auto-generated catch block
		}finally {
			i.reset();
		}
		
	}
	/*
	@Test 
	public void testUpdateEmployeeSame() {
		DataImpl i =new DataImpl();
		try {
			int id = i.createEmployee("Davide","Miro");
			i.createEmployee("Domenico","Cefalo");
			i.updateEmployee(id,"Domenico","Cefalo");
		    fail();
			
		
		} catch (EmployeeException e) {
			assertTrue(true);
			// TODO Auto-generated catch block
		}finally {
			i.reset();
		}
	}
	*/
	
	@Test
	public void testGetEmployeeReport() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add("RECHARGE Davide Miro 10.00 " + String.format("\u20ac"));
		    r1.add("BALANCE Davide Miro caffè 5");
		    r1.add("CASH Davide Miro caffè 6");
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getEmployeeReport(id,df.parse("01-01-2019"),df.parse("31-12-2019"));
			boolean flag = true;
			for(int index = 0 ; index < r1.size() ; index++) {
				if(!report.get(index).contains(r1.get(index))) {
					flag = false;
				}
			}
			
			assertTrue(flag);
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
			for(String s:report) 
				System.out.println(s);
			for(String s:r1)
				System.out.println(s);
		}
	}
	@Test
	public void testGetEmployeeReportNotEmployee() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
					
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getEmployeeReport(1000,df.parse("01-01-2019"),df.parse("31-12-2019"));
			fail();		
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (DateException e) {
			// TODO Auto-generated catch block
			fail();
		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();

		} finally {
				i.reset();
		}
	}
	@Test
	public void testGetEmployeeReportStartNull() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			i.getEmployeeReport(id,null,df.parse("31-12-2019"));
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	@Test
	public void testGetEmployeeReportEndNull() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			i.getEmployeeReport(id,df.parse("31-12-2019"),null);
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetEmployeeReportDatesConsistence() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			i.getEmployeeReport(id,df.parse("31-12-2019"),df.parse("01-01-2019"));
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetEmployeeReportEmptyList() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getEmployeeReport(id,df.parse("01-01-2018"),df.parse("31-12-2018"));
			if(report.isEmpty())
				assertTrue(true);
			else
				fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetReport() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add("RECHARGE Davide Miro 10.00 " + String.format("\u20ac"));
			r1.add("BUY caffè 2");
		    r1.add("BALANCE Davide Miro caffè 5");
		    r1.add("CASH Davide Miro caffè 6");
		    r1.add("VISITOR caffè 3");
		    
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			i.sellCapsulesToVisitor(idc,3);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getReport(df.parse("01-01-2019"),df.parse("31-12-2019"));
			
			boolean flag = true;
			for(int index = 0 ; index < r1.size() ; index++) {
				if(!report.get(index).contains(r1.get(index))) {
					flag = false;
				}
			}
			
			assertTrue(flag);
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetReportStartNull() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
			r1.add(df1.format(new Date())+" BUY caffè 2");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
		    r1.add(df1.format(new Date())+" VISITOR caffè 3");
		    
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			i.sellCapsulesToVisitor(idc,3);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getReport(null,df.parse("31-12-2019"));
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	@Test
	public void testGetReportEndNull() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
			r1.add(df1.format(new Date())+" BUY caffè 2");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
		    r1.add(df1.format(new Date())+" VISITOR caffè 3");
		    
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			i.sellCapsulesToVisitor(idc,3);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getReport(df.parse("31-12-2019"),null);
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetReportDatesConsistence() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
			r1.add(df1.format(new Date())+" BUY caffè 2");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
		    r1.add(df1.format(new Date())+" VISITOR caffè 3");
		    
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			i.sellCapsulesToVisitor(idc,3);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getReport(df.parse("31-12-2019"),df.parse("01-01-2019"));
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void testGetReportEmptyList() {
		DataImpl i = new DataImpl();
		int id=0;
		int idc= 0;
		List<String> report = null;
		List<String> r1 = new ArrayList<>();
		try {
			id =i.createEmployee("Davide","Miro");
			idc =i.createBeverage("caffè",50,100);
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			r1.add(df1.format(new Date())+ " RECHARGE Davide Miro 10,00 €");
			r1.add(df1.format(new Date())+" BUY caffè 2");
		    r1.add(df1.format(new Date())+ " BALANCE Davide Miro caffè 5");
		    r1.add(df1.format(new Date())+ " CASH Davide Miro caffè 6");
		    r1.add(df1.format(new Date())+" VISITOR caffè 3");
		    
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,5,true);
			i.sellCapsules(id,idc,6,false);
			i.sellCapsulesToVisitor(idc,3);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			report = i.getReport(df.parse("01-01-2018"),df.parse("01-12-2018"));
			if(report.isEmpty())
				assertTrue(true);
			else
				fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			fail();
		} catch (DateException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			fail();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
		}finally {
			i.reset();
		}
	}
	@Test
	public void testGetEmployeeNameNotId() {
		DataImpl i = new DataImpl();
		try {
			i.getEmployeeName(1000);
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}
		
	}
	@Test
	public void testGetEmployeeSuranameNotId() {
		DataImpl i = new DataImpl();
		try {
			i.getEmployeeSurname(1000);
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}finally {
			i.reset();
		}
		
	}
	@Test
	public void testGetEmployeeBalanceNotId() {
		DataImpl i = new DataImpl();
		try {
			i.getEmployeeBalance(1000);
			fail();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}finally {
			i.reset();
		}
		
	}
	
	@Test
	public void testGetEmployeeId() {
		DataImpl i = new DataImpl();
		int id1 = 0;
		int id2 = 0;
		try {
		    id1 =i.createEmployee("Davide","Miro");
			id2 =i.createEmployee("Domenico","Cefalo");
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		}
		
		List<Integer> list=new ArrayList<>();
		list.add(id1);
		list.add(id2);
		if(list.equals(i.getEmployeesId()))
			assertTrue(true);
		else
			fail();	
	}
	@Test
	public void testGetEmployees() {
		DataImpl i = new DataImpl();
		int id1 = 0;
		int id2 = 0;
		try {
		    id1 =i.createEmployee("Davide","Miro");
			id2 =i.createEmployee("Domenico","Cefalo");
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
		}
		
		Map<Integer,String> list=new HashMap();
		list.put(id1,new String("Davide Miro"));
		list.put(id2,new String("Domenico Cefalo"));
		if(list.equals(i.getEmployees()))
			assertTrue(true);
		else
			fail();	
		
	}
	@Test
	public void testReadFilesZeroTime() {
		DataImpl i = new DataImpl();
	}
	@Test
	public void testReadFilesOneTime() {
		DataImpl i = new DataImpl();
		try {
			int id = i.createEmployee("Davide","Miro");
			i.rechargeAccount(id,1000);

		} catch (EmployeeException e) {
			// TODO Auto-generated catch block	
		}
		DataImpl i2 = new DataImpl();
		i2.reset();
		
	}
	@Test
	public void testReadFilesMultipleTimes() {
		DataImpl i = new DataImpl();
		try {
			int id = i.createEmployee("Davide","Miro");
			int idc = i.createBeverage("caffè",50,100);
			i.rechargeAccount(id,1000);
			i.buyBoxes(idc,2);
			i.sellCapsules(id,idc,10,true);
			i.sellCapsules(id,idc,6,false);
			i.sellCapsulesToVisitor(idc,2);
			i.updateBeverage(idc,"thè",30,60);
			i.updateEmployee(idc,"Domenico","Cefalo");
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnoughCapsules e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DataImpl i2 = new DataImpl();
		i2.reset();
	}
	@Test
	public void testChangeSellWithAccountWhiteBox() {
		DataImpl i = new DataImpl();
		try {
			int e =i.createEmployee("Mario","Rossi");
			int id =i.createBeverage("Caffè",10,10);
			i.rechargeAccount(e,100000);
			i.buyBoxes(id,1);
			i.updateBeverage(id,"Caffè",10,20);
			i.buyBoxes(id,1);
			i.sellCapsules(e,id,12,true);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnoughCapsules e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotEnoughBalance e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			i.reset();
		}
		
	}
	@Test
	public void testChangeSellNoAccountWhiteBox() {
		DataImpl i = new DataImpl();
		try {
			int e =i.createEmployee("Mario","Rossi");
			int id =i.createBeverage("Caffè",10,10);
			i.rechargeAccount(e,100000);
			i.buyBoxes(id,1);
			i.updateBeverage(id,"Caffè",10,20);
			i.buyBoxes(id,1);
			i.sellCapsules(e,id,12,false);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnoughCapsules e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotEnoughBalance e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			i.reset();
		}
		
	}
	@Test
	public void testChangeSelltoVisitorWhiteBox() {
		DataImpl i = new DataImpl();
		try {
			int e =i.createEmployee("Mario","Rossi");
			i.rechargeAccount(e,100000);
			int id =i.createBeverage("Caffè",10,10);
			i.buyBoxes(id,1);
			i.updateBeverage(id,"Caffè",10,20);
			i.buyBoxes(id,1);
			i.sellCapsulesToVisitor(id,12);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnoughBalance e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotEnoughCapsules e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally {
			i.reset();
		}
	}
}
	
		
	
		
	
	
	
	

	
	
	
	





