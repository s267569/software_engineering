package it.polito.latazza.data;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import it.polito.latazza.data.TestDataImpl;
import it.polito.latazza.exceptions.*;

class AcceptanceTest {

	@Test
	public void scenario1Test() {
		new TestDataImpl().testSellWithAccount();
	}
	
	@Test
	public void scenario2Test() {
		
		DataImpl i = new DataImpl();
		
		try {
			//balance = 1000
			int  id = i.createEmployee("Davide","Miro");
			int id1 = i.createEmployee("Domenico","Cefalo");
			int idc = i.createBeverage("caffe",50,100);
			//i.rechargeAccount(id,100);
			i.rechargeAccount(id1,1000);
			i.buyBoxes(idc,2); // availability = 100
			i.sellCapsules(id,idc,10,true);
			assertTrue(-20 == i.getEmployeeBalance(id));
			assertTrue(90 == i.getBeverageCapsules(idc));
			assertTrue(800 == i.getBalance());
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		} catch (NotEnoughCapsules e) {
			fail();
			
			e.printStackTrace();
		} catch (BeverageException e) {
			// TODO Auto-generated catch block
			fail();
			e.printStackTrace();
		}finally {
			i.reset();
		}
	}
	
	@Test
	public void scenario3Test() {
		new TestDataImpl().testRechargeAccount();
	}
	
	@Test
	public void scenario4Test() {
		new TestDataImpl().testBuyBoxes();
	}
	
	@Test
	public void scenario5Test() {
		new TestDataImpl().testGetEmployeeReport();
	}
	
	@Test
	public void scenario6Test() {
		new TestDataImpl().testGetReport();
	}
	
	@Test
	public void scenario7Test() {
		new TestDataImpl().testSellVisitor();
	}
	
	@Test
	public void testNFR2() {
		long fine = 0;
		long inizio = 0;
		
		inizio = System.currentTimeMillis();
		scenario1Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		inizio = System.currentTimeMillis();
		scenario2Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		inizio = System.currentTimeMillis();
		scenario3Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		inizio = System.currentTimeMillis();
		scenario4Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		inizio = System.currentTimeMillis();
		scenario5Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		inizio = System.currentTimeMillis();
		scenario6Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		inizio = System.currentTimeMillis();
		scenario7Test();
		fine =System.currentTimeMillis();
		if((fine - inizio)>= 500) {
			fail();
			return;
		}
		assertTrue(true);
	}
	
	
}
